declare module 'lucide' {
  const anyExport: any
  export default anyExport
  export const createIcons: (...args: any[]) => void
}
